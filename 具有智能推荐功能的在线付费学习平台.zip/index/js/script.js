/**
 * 加入购物车
 */
function buy(productid){
	//在这里调用控制器，并获取返回值
	$.post("buy.action",{productid:productid}, function(data){
		if(data=="ok"){
			layer.msg("操作成功!");
			location.reload();
		}else if(data=="login"){
			alert("请您登录后再购买课程!");
			location.href="login.jsp";
		}else if(data=="repeat"){
			alert("该项已在订单中，请勿重复操作!");
		}else{
			alert("请求失败!");
		}
	});
}

/**
 * 购物车删除
 */
function deletes(productid){
	alert(1);
	$.post("delete.action", {productid:productid}, function(data){
		alert("删除了第"+productid);
		if(data=="ok"){
			layer.msg("删除成功!");
			location.reload();
		}else if(data=="login"){
			alert("请您登录后再进行操作!");
			location.href="login.jsp";
		}else{
			alert("请求失败!");
		}
	});
}

/**
 * 观看视频
 */
function see(productid){
	alert("请求失败!");
	//在这里调用控制器，并获取返回值
	$.post("videoplay.action",{productid:productid}, function(data){
		if(data=="login"){
			alert("请您登录后再观看视频!");
			location.href="login.jsp";
		}else{
			alert("请求失败!");
		}
	});
}